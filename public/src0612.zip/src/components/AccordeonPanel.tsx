export default function AccordeonPanel() {

}