# React + Vite


Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

  https://medium.com/@amitbar131/mastering-maps-in-react-a-comprehensive-guide-to-using-react-google-maps-api-cd4be60d922a
- https://github.com/dimsemenov/photoswipe-dynamic-caption-plugin?tab=readme-ov-file
utiliser font awesome plutot, material prends 3 mo !!
- https://medium.com/@devpedrodias/how-to-use-i18n-in-your-react-app-1f26deb2a3d8
- https://vitejs.github.io/vite-plugin-react-pages/i18n