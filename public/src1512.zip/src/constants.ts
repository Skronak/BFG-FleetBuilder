export enum TypeActionButton {
    CONSULTER = 'CONSULTER',
    MODIFIER = 'MODIFIER',
    SUPPRIMER = 'SUPPRIMER',
}