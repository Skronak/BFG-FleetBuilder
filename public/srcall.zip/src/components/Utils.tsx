export function getAssetUrl(name: string) {
    return new URL(`/src/assets/${name}`, import.meta.url).href;
}