const Products: React.FC = () => {
    return (
        <div>
            <h1>Products</h1>
            <ul>
                <li>Product 1</li>
                <li>Product 2</li>
                <li>Product 3</li>
            </ul>
        </div>
    );
};export default Products;