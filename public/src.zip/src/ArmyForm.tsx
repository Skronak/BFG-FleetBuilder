import { useState } from 'react';
import Row from "./Row";
import InputAddComponent from "./inputAddComponent";
import InputField from "./components/InputField"
import "./armyform.css";
import uuid from "uuid";
import {PlayerUnit, Warband, WarBandRule} from "./army";
import Modal from './components/Modal'

interface Props {
  warband: Warband;
}

function ArmyForm({warband}: Props) {
  const uuid = require('uuid');
  const [openModal, setOpenModal] = useState(false);
  const [heroes, setHeroes] = useState<PlayerUnit[]>([]);
  const [cost, setCost] = useState<number>(0);

  const [henchmen, setHenchmen] = useState([
    { id: uuid.v1(), task: "task 1", completed: false },
    { id: uuid.v1(), task: "task 2", completed: true }
  ]);

  const create = (newTodo: { id: string; task: string; completed: boolean; }) => {
    setHenchmen([...henchmen, newTodo]);
  };

  const calculatCost = () => {
//    setCost(heroes.map(value => value.))
  }
  const remove = (id: string) => {
    setHenchmen(henchmen.filter(todo => todo.id !== id));
  };

  const update = (id: string, updtedTask: any) => {
    const units = henchmen.map(todo => {
      if (todo.id === id) {
        return { ...todo, task: updtedTask };
      }
      return todo;
    });
    setHenchmen(units);
  };

  const toggleComplete = (id: string) => {
    const updatedunits = henchmen.map(todo => {
      if (todo.id === id) {
        return { ...todo, completed: !todo.completed };
      }
      return todo;
    });
    setHenchmen(updatedunits);
  };

  return (
    <div>
      <h1>
        <InputField defaultValue={'New warband'} subClass='' />
      </h1>
      <div className={"title-cost"}>
        cost: {cost} points
      </div>

      {openModal && (
        <Modal
            onClose={()=>(setOpenModal(false))}
            data={warband.rules.heroes}
            onValidate={(val: any)=> setHeroes([
              ...heroes,
              { id: val.id }
            ])}
        />
      )}

      {warband[Object.getOwnPropertyNames(warband.rules)]}.map(f => ({
        <>
          <h2 className={'army-form-label'}>Heroes<button className="button-icon" onClick={()=>setOpenModal(true)}><i className="fa fa-plus-circle"></i></button></h2>
          {heroes.map(hero => (
            <Row
                toggleComplete={toggleComplete}
                update={update}
                remove={remove}
                key={hero.id}
                todo={hero}
                data={f}
            />))}
        </>
      )});
      <h2 className={'army-form-label'}>Henchmen<button className="button-icon" onClick={()=>setOpenModal(true)}><i className="fa fa-plus-circle"></i></button></h2>
      {henchmen.map(unit => (
        <Row
            toggleComplete={toggleComplete}
            update={update}
            remove={remove}
            key={unit.id}
            todo={unit}
            data={warband.rules.henchmen}
        />
      ))}
      <InputAddComponent createRow={create} />
    </div>
  );
}

export default ArmyForm;
